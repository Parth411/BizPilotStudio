BIZPILOT STUDIO — SMALL BUSINESS MANAGEMENT WORKBOOK V15.1

YOUR DOWNLOAD INCLUDES TWO WORKBOOK EDITIONS:

1) BizPilot-Studio-Workbook-V15.1-DEMO.xlsx
   Open this first to explore the workbook. It contains fictional example leads,
   clients, services, quotations, projects, invoices, payments and expenses.
   Demo records are clearly labelled. All names, contact details, IDs and
   transactions are fictional examples. Do not use them as real records.

2) BizPilot-Studio-Workbook-V15.1-BLANK.xlsx
   This is the clean edition for your own business. It contains the same
   workbook tools without sample business records. Use this for real data.

3) BizPilot-Studio-Workbook-User-Guide.pdf
   Step-by-step instructions for setup, quotations, invoices, payments,
   expenses, dashboards, reporting and troubleshooting.

RECOMMENDED START
- Open the DEMO workbook first and explore the sample workflow.
- Read the PDF guide.
- When ready, open the BLANK workbook and enter your own business information.

REQUIREMENTS AND IMPORTANT NOTES
- Designed for Microsoft Excel; no macros are used.
- Use one currency consistently in a workbook.
- Tax and invoice requirements vary by location; verify local rules independently.
- This is an operational spreadsheet, not accounting, tax, legal or regulatory advice.
- Keep your own backups and protect customer/financial data.
