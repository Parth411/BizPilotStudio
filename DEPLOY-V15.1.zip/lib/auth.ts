import 'server-only';
import { cookies } from 'next/headers';
import { createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { sql } from '@/lib/db';

const scrypt = promisify(scryptCallback);
const COOKIE_NAME = 'bps_session';
const SESSION_DAYS = 30;
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function normalizeEmail(value: unknown) {
  const email = String(value ?? '').trim().toLowerCase();
  if (email.length > 254 || !emailPattern.test(email)) throw new Error('Enter a valid email address.');
  return email;
}

export async function hashPassword(password: string) {
  if (password.length < 10 || password.length > 200) throw new Error('Password must be 10–200 characters long.');
  const salt = randomBytes(16);
  const derived = await scrypt(password, salt, 64) as Buffer;
  return `scrypt$${salt.toString('hex')}$${derived.toString('hex')}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [scheme, saltHex, hashHex] = stored.split('$');
  if (scheme !== 'scrypt' || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, 'hex');
  const actual = await scrypt(password, Buffer.from(saltHex, 'hex'), expected.length) as Buffer;
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

function tokenDigest(token: string) { return createHash('sha256').update(token).digest('hex'); }

export async function createSession(customerId: string) {
  const token = randomBytes(32).toString('base64url');
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000);
  await sql`INSERT INTO customer_sessions (customer_id, token_hash, expires_at) VALUES (${customerId}, ${tokenDigest(token)}, ${expiresAt.toISOString()})`;
  const jar = await cookies();
  jar.set(COOKIE_NAME, token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'lax', path: '/', expires: expiresAt });
}

export async function getCurrentCustomer() {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (!token) return null;
  const rows = await sql`SELECT c.id, c.email, c.first_name, c.last_name, c.phone FROM customer_sessions s JOIN customers c ON c.id = s.customer_id WHERE s.token_hash = ${tokenDigest(token)} AND s.expires_at > NOW() LIMIT 1`;
  return rows[0] ?? null;
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(COOKIE_NAME)?.value;
  if (token) await sql`DELETE FROM customer_sessions WHERE token_hash = ${tokenDigest(token)}`;
  jar.delete(COOKIE_NAME);
}
