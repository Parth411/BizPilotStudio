export type Product = {
  slug: string;
  name: string;
  category: string;
  categorySlug: string;
  description: string;
  price: number;
  oldPrice?: number;
  format: string;
  badge?: string;
  visual: "sheet" | "doc" | "planner" | "creative" | "bundle" | "slides";
  features: string[];
};

// Only products with a real, prepared downloadable file are published for sale.
export const products: Product[] = [
  {
    slug: "small-business-management-workbook",
    name: "Small Business Management Workbook",
    category: "Business Tools",
    categorySlug: "business-tools",
    description:
      "A 17-sheet Excel toolkit to manage leads, clients, multi-item quotations, projects, invoices, payments and expenses, with a business dashboard and rolling 12-month report.",
    price: 799,
    format: "Excel workbook + PDF guide (.zip)",
    badge: "V15.1 • Business Insights",
    visual: "sheet",
    features: [
      "17 worksheets for everyday small-business operations",
      "Dashboard with year-to-date performance KPIs",
      "Lead and client trackers with follow-up workflow",
      "Multi-item quotations with automatic line calculations",
      "Project, invoice, part-payment and balance tracking",
      "Expense log and rolling 12-month financial report",
      "A4 quotation and invoice print templates for up to 12 items",
      "PDF customer guide and quick-start instructions included",
    ],
  },
];

export const categories = [
  {
    name: "Business Tools",
    slug: "business-tools",
    description: "Track, plan and manage everyday business work.",
  },
];

export function getProduct(slug: string) {
  return products.find((product) => product.slug === slug);
}
