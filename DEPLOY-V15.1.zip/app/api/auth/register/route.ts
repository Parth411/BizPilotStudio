import { NextRequest, NextResponse } from 'next/server';
import { createSession, hashPassword, normalizeEmail } from '@/lib/auth';
import { sql } from '@/lib/db';
export const runtime = 'nodejs';
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const email = normalizeEmail(body.email);
    const firstName = String(body.firstName ?? '').trim();
    const lastName = String(body.lastName ?? '').trim();
    const phone = String(body.phone ?? '').trim().slice(0, 40) || null;
    if (!firstName || !lastName || firstName.length > 80 || lastName.length > 80) return NextResponse.json({ error: 'Enter your first and last name.' }, { status: 400 });
    const passwordHash = await hashPassword(String(body.password ?? ''));
    const rows = await sql`INSERT INTO customers (email, password_hash, first_name, last_name, phone) VALUES (${email}, ${passwordHash}, ${firstName}, ${lastName}, ${phone}) ON CONFLICT (email) DO NOTHING RETURNING id, email, first_name, last_name`;
    if (!rows.length) return NextResponse.json({ error: 'An account with this email already exists. Please sign in.' }, { status: 409 });
    await createSession(String(rows[0].id));
    return NextResponse.json({ customer: rows[0] }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Could not create your account.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
