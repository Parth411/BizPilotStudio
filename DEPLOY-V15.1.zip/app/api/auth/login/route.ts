import { NextRequest, NextResponse } from 'next/server';
import { createSession, normalizeEmail, verifyPassword } from '@/lib/auth';
import { sql } from '@/lib/db';
export const runtime = 'nodejs';
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const email = normalizeEmail(body.email);
    const password = String(body.password ?? '');
    const rows = await sql`SELECT id, email, password_hash, first_name, last_name FROM customers WHERE email = ${email} LIMIT 1`;
    const customer = rows[0];
    if (!customer || !(await verifyPassword(password, String(customer.password_hash)))) return NextResponse.json({ error: 'Email or password is incorrect.' }, { status: 401 });
    await createSession(String(customer.id));
    return NextResponse.json({ customer: { id: customer.id, email: customer.email, first_name: customer.first_name, last_name: customer.last_name } });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Could not sign in.';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
