import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, CheckCircle2, Download, ShieldCheck, Eye } from "lucide-react";
import { products } from "@/lib/products";
import { ProductPreview } from "@/components/product-preview";
import { AddToCart } from "@/components/add-to-cart";
import { LocalizedPrice } from "@/components/localized-price";

export function generateStaticParams() {
  return products.map((product) => ({ slug: product.slug }));
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = products.find((item) => item.slug === slug);
  if (!product) notFound();

  return (
    <section className="container page">
      <Link className="back" href="/shop"><ArrowLeft size={15}/> Back to shop</Link>
      <div className="detail">
        <div className="detailart">
          <img className="product-hero-preview" src="/previews/dashboard.png" alt="Actual V15.1 workbook dashboard preview" />
          <a className="preview-cta" href="#product-preview"><Eye size={16}/> View actual workbook previews</a>
        </div>
        <div>
          <small>{product.category}</small>
          <h1>{product.name}</h1>
          <p className="description">{product.description}</p>
          <div className="detailprice"><LocalizedPrice amount={product.price}/></div>
          <p className="format">DOWNLOAD PACKAGE: Excel workbook + PDF user guide + quick-start notes</p>
          <AddToCart product={product}/>
          <p className="preview-note">Blank-use edition. The package contains no demonstration customer or transaction records.</p>
          <div className="delivery">
            <span><Download/> Digital product</span>
            <span><ShieldCheck/> Secure checkout and protected download</span>
          </div>
          <h3>What’s included</h3>
          {product.features.map((feature) => <p className="feature" key={feature}><CheckCircle2/> {feature}</p>)}
        </div>
      </div>
      <section id="product-preview" className="preview-section">
        <div className="sectionhead">
          <div><small>TAKE A CLOSER LOOK</small><h2>Preview the workbook.</h2></div>
          <span>4 actual workbook views</span>
        </div>
        <ProductPreview/>
      </section>
    </section>
  );
}
