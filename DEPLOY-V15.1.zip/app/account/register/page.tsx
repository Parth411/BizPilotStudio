import Link from 'next/link';
import { AccountForm } from '@/components/account-form';
export default function Page() { return <section className="container page"><div className="intro"><small>MY ACCOUNT</small><h1>Create your BizPilot account.</h1><p>Sign in to manage purchases and access your downloads.</p></div><div className="summary"><AccountForm mode="register"/><p><Link href="/account/login">Already have an account? Sign in</Link></p></div></section>; }
