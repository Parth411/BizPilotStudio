"use client";

import { useState } from "react";
import { Maximize2 } from "lucide-react";

const previews = [
  { src: "/previews/dashboard.png", label: "Dashboard — live workbook view" },
  { src: "/previews/monthly-report.png", label: "Rolling 12-month report" },
  { src: "/previews/quotation-v15.png", label: "Multi-item quotation print" },
  { src: "/previews/invoice-v15.png", label: "Invoice with payment balance" },
];

export function ProductPreview() {
  const [active, setActive] = useState(0);
  return (
    <div className="product-preview">
      <div className="product-preview-main">
        <img src={previews[active].src} alt={`${previews[active].label} workbook preview`} />
        <span className="preview-caption">{previews[active].label}</span>
        <a href={previews[active].src} target="_blank" rel="noreferrer" aria-label="Open full-size preview"><Maximize2 size={17}/></a>
      </div>
      <div className="product-preview-thumbs" aria-label="Workbook preview pages">
        {previews.map((item, index) => (
          <button key={item.src} className={active === index ? "active" : ""} onClick={() => setActive(index)} aria-pressed={active === index}>
            <img src={item.src} alt="" />
            <span>{item.label}</span>
          </button>
        ))}
      </div>
      <p className="preview-note">Screenshots are rendered from the V15.1 workbook using fictional demonstration records. Your download is a clean blank edition with editable sheets and formulas.</p>
    </div>
  );
}
