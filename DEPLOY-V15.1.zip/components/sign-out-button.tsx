'use client';
import { useRouter } from 'next/navigation';
export function SignOutButton() { const router = useRouter(); return <button className="btn secondary" onClick={async () => { await fetch('/api/auth/logout', { method: 'POST' }); router.replace('/account/login'); router.refresh(); }}>Sign out</button>; }
